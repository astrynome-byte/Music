# OpenScore — Dix chants et mélodies, version 0.1.2

Dix vraies partitions éditables pour Cadence Studio : neuf chants avec piano et un duo de sopranos avec piano, de Schubert, Robert et Clara Schumann, Fanny Hensel, Fauré et Felix Mendelssohn. Les textes sont allemands et français, avec aussi l’original italien historique d’Après un rêve. Ce petit fonds est optionnel ; il ne contient ni application, ni enregistrement, ni catalogue commercial.

## Ajouter les partitions

1. Dans Windows, faites un clic droit sur le ZIP, puis **Extraire tout…** dans **Documents**, par exemple `Documents\Cadence — Dix chants`. Gardez le dossier extrait à cet endroit.
2. Ouvrez Cadence Studio, puis **Accueil → Partitions → Bibliothèque locale → Ajouter des partitions…**.
3. Dans le dossier extrait, ouvrez **working** et sélectionnez ses **10 fichiers MSCX/MSCZ**. N’ajoutez pas aussi ceux du dossier originals, pour éviter les doublons.
4. Ouvrez une partition depuis la bibliothèque. Vous pouvez créer la collection **OpenScore — Dix chants et mélodies** si vous utilisez les collections.

Vos fichiers restent locaux. L’ajout garde une référence vers leur emplacement : il n’envoie pas ces partitions à un serveur et ne les déplace pas. Conservez donc le dossier extrait. Les anciens liens web présents dans les crédits restent des références ; le cœur de l’édition et de la lecture fonctionne hors ligne. Aucun compte ni abonnement n’est nécessaire pour ce fonds. L’application doit être installée séparément.

Les fichiers `working` sont des copies exactes des sources conservées dans `originals`. Pour une première modification ou une conversion vers un format plus récent, utilisez **Enregistrer sous…** avec un nouveau nom ; gardez vos originaux. Les éditions proviennent de plusieurs versions de MuseScore. Le test couvre ces dix fichiers, sans garantir tous les fichiers de ces anciennes versions.

## Ce qui a été vérifié

Le 12 novembre 2026, Cadence Studio 4.7.6, stage Windows 2006 authentifié, a exécuté **40 commandes sur 10 partitions** : ouverture/export PDF, sauvegarde MSCZ, réouverture/export PDF et export WAV. Vingt conteneurs PDF, dix MSCZ réouverts et dix WAV Float32 stéréo à 44 100 Hz ont passé les contrôles. Les WAV sont finis et non muets, sans échantillon au plein niveau numérique ; cela ne remplace pas une écoute. Aucun fichier musical, gain ou timbre n’a été changé pour ces essais.

`collection-index.csv` donne les durées de rendu réellement mesurées, entre 57,78 et 199,571 secondes. Elles incluent les reprises et queues sonores du rendu ; ce ne sont pas des durées de concert. `evidence/windows-qualification-receipt.json` contient le reçu compact, le lien du job, les empreintes et les limites. Les PDF, WAV et sauvegardes converties de test ne sont pas inclus.

L’ouverture graphique depuis cette bibliothèque, l’édition/annulation, la mise en page visuelle, les rythmes/articulations/paroles détaillés et l’écoute humaine restent à vérifier. Les contrôles de structure comparent les nombres de parties/portées/mesures/notes, les hauteurs, les fragments de paroles et la mention CC0 ; ils ne prouvent pas chaque détail musical. Le job ne teste pas la sauvegarde après lecture dans une même session ouverte.

Les voix utilisent les timbres guides des éditions : notamment hautbois MIDI, flûte à bec, clarinette ou flûte ; aucun chant humain enregistré n’est fourni. Les trois MSCZ modernes conservent MS Basic explicite ; les sept MSCX anciens ont une carte de pistes audio vide dans leur sauvegarde et rendent ensuite un WAV non muet dans un processus distinct. Le moteur a signalé en INFO le MuseSampler optionnel absent ; ce rendu a tout de même abouti. Les choix encodés, dont le nom Violoncelle dans Après un rêve, sont conservés et décrits au manifeste.

## Sources, droits et contenu local

Les encodages OpenScore/Lieder sont dédiés sous **CC0 1.0**, au commit `38c5db510224d9facdc4b08d741fc788cfb58ea8`. Les compositions et textes originaux sont anciens et leurs auteurs identifiés ; le périmètre documentaire est la France/UE en 2026. Les sources, crédits et licence complète figurent dans `notices/`, les README par édition et `evidence/rights-and-repository-audit.json`. Aucun scan ou enregistrement tiers n’est redistribué.

Cette version 0.1.2 ne change que la documentation du pack testé 0.1.1. Les 20 fichiers musicaux originaux et working restent identiques octet par octet, preuve dans `evidence/musical-files-unchanged.json`. Ce fonds est distinct de l’installateur et n’ajoute aucune collection automatiquement au profil. `SHA256SUMS.txt` identifie tous les fichiers du dossier.
