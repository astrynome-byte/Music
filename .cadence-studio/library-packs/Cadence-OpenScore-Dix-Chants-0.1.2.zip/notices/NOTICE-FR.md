# Dix chants et mélodies — sources et crédits


Les compositions et textes originaux sélectionnés sont anciens ; leurs auteurs et les notices institutionnelles correspondantes figurent dans collection-manifest.json. Les encodages modernes sont explicitement dédiés sous CC0 1.0 par OpenScore Lieder. Leurs mentions sont conservées dans les fichiers.

Merci aux contributeurs OpenScore Lieder : https://github.com/OpenScore/Lieder

Révision source : 38c5db510224d9facdc4b08d741fc788cfb58ea8.

Aucun enregistrement, scan IMSLP ou accès au catalogue MuseScore.com n’est fourni. Les liens historiques contenus dans les éditions originales sont des références.


## Heidenröslein, D.257

Franz Schubert — texte : Johann Wolfgang von Goethe. Voix et piano.

Transcribed from the IMSLP file(s) at https://imslp.org/wiki/Special:ReverseLookup/09270

Édition Git : https://github.com/OpenScore/Lieder/blob/38c5db510224d9facdc4b08d741fc788cfb58ea8/scores/Schubert,_Franz/Op.3/3_Heidenröslein,_D.257/lc30321236.mscz

Source historique déclarée par l’édition : https://imslp.org/wiki/Special:ReverseLookup/09270

Licence de l’encodage : CC0-1.0 ; SHA-256 116335e8014277a4d1a77f8b3a2731fee62741f02e237999e1b48dffe0f37ee1.


## An die Musik

Franz Schubert — texte : Franz von Schober. Voix et piano.

Transcribed by Mark Gotham from IMSLP #364857: holograph manuscript (1817). Source: https://imslp.org/wiki/An_die_Musik,_D.547_(Schubert,_Franz)

Édition Git : https://github.com/OpenScore/Lieder/blob/38c5db510224d9facdc4b08d741fc788cfb58ea8/scores/Schubert,_Franz/_/An_die_Musik,_D.547/lc6180725.mscx

Source historique déclarée par l’édition : https://imslp.org/wiki/Special:ReverseLookup/364857

Licence de l’encodage : CC0-1.0 ; SHA-256 4c83578fece90e1f12ae9960db7689e6132c8f901d189d5f7571dcf51c302443.


## Im wunderschönen Monat Mai

Robert Schumann — texte : Heinrich Heine. Voix et piano.

Transcribed from the IMSLP file(s) at https://imslp.org/wiki/Special:ReverseLookup/51736

Édition Git : https://github.com/OpenScore/Lieder/blob/38c5db510224d9facdc4b08d741fc788cfb58ea8/scores/Schumann,_Robert/Dichterliebe,_Op.48/01_Im_wunderschönen_Monat_Mai/lc4976777.mscz

Source historique déclarée par l’édition : https://imslp.org/wiki/Special:ReverseLookup/51736

Licence de l’encodage : CC0-1.0 ; SHA-256 9a9a67de4179940e748db3e825b9b71f1af7edb0dfbc2755fb820d233c2dbff7.


## Aus meinen Tränen spriessen

Robert Schumann — texte : Heinrich Heine. Voix et piano.

Transcribed by pental from IMSLP #51736.

Édition Git : https://github.com/OpenScore/Lieder/blob/38c5db510224d9facdc4b08d741fc788cfb58ea8/scores/Schumann,_Robert/Dichterliebe,_Op.48/02_Aus_meinen_Tränen_sprießen/lc4976769.mscx

Source historique déclarée par l’édition : https://imslp.org/wiki/Special:ReverseLookup/51736

Licence de l’encodage : CC0-1.0 ; SHA-256 de4ff109ea9d0a2dd0b2c5fbeb7762ba0a698a0133969c49c831f8057b82e2ca.


## Die Lotosblume

Robert Schumann — texte : Heinrich Heine. Voix et piano.

Transcribed by flutemouse from IMSLP #270905. Source: https://imslp.org/wiki/Special:ReverseLookup/270905

Édition Git : https://github.com/OpenScore/Lieder/blob/38c5db510224d9facdc4b08d741fc788cfb58ea8/scores/Schumann,_Robert/Myrthen,_Op.25/07_Die_Lotosblume/lc6909797.mscx

Source historique déclarée par l’édition : https://imslp.org/wiki/Special:ReverseLookup/270905

Licence de l’encodage : CC0-1.0 ; SHA-256 4d9f8de8786ac7b960a1af01a56f0ed08785b4c968563e48fe2108a69da55f25.


## Liebst du um Schönheit

Clara Schumann — texte : Friedrich Rückert. Voix et piano.

Contributeurs OpenScore Lieder ; crédits détaillés non renseignés dans les métadonnées de ce fichier.

Édition Git : https://github.com/OpenScore/Lieder/blob/38c5db510224d9facdc4b08d741fc788cfb58ea8/scores/Schumann,_Clara/Lieder,_Op.12/04_Liebst_du_um_Schönheit/lc5000397.mscx

Source historique déclarée par l’édition : https://imslp.org/wiki/Special:ReverseLookup/454110

Licence de l’encodage : CC0-1.0 ; SHA-256 e1100541ab1b4643530088be1b38c9a93f21eea1dc0a740066475f02aa754673.


## Warum sind denn die Rosen so blass?

Fanny Hensel (Mendelssohn) — texte : Heinrich Heine. Voix et piano.

Contributeurs OpenScore Lieder ; crédits détaillés non renseignés dans les métadonnées de ce fichier.

Édition Git : https://github.com/OpenScore/Lieder/blob/38c5db510224d9facdc4b08d741fc788cfb58ea8/scores/Hensel,_Fanny/6_Lieder,_Op.1/3_Warum_sind_denn_die_Rosen_so_blass/lc5004640.mscx

Source historique déclarée par l’édition : https://imslp.org/wiki/Special:ReverseLookup/99178

Licence de l’encodage : CC0-1.0 ; SHA-256 90da2b96d68a09d90cf947f042867c948f4d5a47b0020c15902d2b26ca633334.


## Lydia

Gabriel Fauré — texte : Leconte de Lisle. Voix et piano.

Transcribed from the IMSLP file(s) at https://imslp.org/wiki/Special:ReverseLookup/24045

Édition Git : https://github.com/OpenScore/Lieder/blob/38c5db510224d9facdc4b08d741fc788cfb58ea8/scores/Fauré,_Gabriel/Op.4/2_Lydia/lc30299786.mscz

Source historique déclarée par l’édition : https://imslp.org/wiki/Special:ReverseLookup/24045

Licence de l’encodage : CC0-1.0 ; SHA-256 25a5b3246688bbb792563667c1b525593eee2d4a4cc6203a2ebdbaf3eac10c4b.


## Après un rêve

Gabriel Fauré — texte : Romain Bussine. Voix et piano.

Transcribed by ashmoggs from IMSLP #24047 Source: https://imslp.org/wiki/Special:ReverseLookup/24047

Édition Git : https://github.com/OpenScore/Lieder/blob/38c5db510224d9facdc4b08d741fc788cfb58ea8/scores/Fauré,_Gabriel/3_Songs,_Op.7/1_Après_un_rêve/lc6810863.mscx

Source historique déclarée par l’édition : https://imslp.org/wiki/Special:ReverseLookup/24047

Licence de l’encodage : CC0-1.0 ; SHA-256 67720d2f82a2ea89e7afaf4e67c00f4e7a94fbab73f338b88e1945cf85a7f7c7.


## Ich wollt' meine Lieb' ergösse sich, MWV J 5. (1836)

Felix Mendelssohn Bartholdy — texte : Heinrich Heine. Deux sopranos et piano.

Transcribed by Mélisande from IMSLP #41097, edited by Vinckenbosch, reviewed by DanielR. Source: https://imslp.org/wiki/Special:ReverseLookup/41097

Édition Git : https://github.com/OpenScore/Lieder/blob/38c5db510224d9facdc4b08d741fc788cfb58ea8/scores/Mendelssohn,_Felix/6_Duets,_Op.63/1_Ich_wollt’,_meine_Lieb’_ergösse_sich,_MWV_J_5/lc7074684.mscx

Source historique déclarée par l’édition : https://imslp.org/wiki/Special:ReverseLookup/41097

Licence de l’encodage : CC0-1.0 ; SHA-256 d5ab957b25374192cd1e3cf497812493b2e5412baf5dc5e560dd333a90708807.



## Précision sur les deux textes d’Après un rêve

Le fichier original contient l’adaptation française de Romain Bussine (1830–1899) et le poème italien anonyme. La notice BnF de l’œuvre identifie cet original et la première édition musicale de 1878 : https://catalogue.bnf.fr/ark:/12148/cb13912075q . Les notes de Graham Johnson identifient la source italienne dans Canti popolari, Venise, 1841, recueillis par Niccolò Tommaseo : https://www.hyperion-records.co.uk/dw.asp?dc=W168_GBLLH1642715 . Ces faits sont résumés ; le texte des notes et l’enregistrement commercial ne sont pas redistribués. Les métadonnées de la page IMSLP associent #24047 à l’édition Hamelle vers 1878, marquée Public Domain ; aucun scan n’est fourni. Les deux textes anciens restent dans le score, sans suppression ni modernisation.
