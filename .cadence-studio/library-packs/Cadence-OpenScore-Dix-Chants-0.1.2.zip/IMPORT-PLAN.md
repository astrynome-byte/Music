# Import local du fonds OpenScore

Le parcours utilisateur est décrit dans README.md et LIRE-MOI.txt : extraire dans Documents, puis ajouter les dix fichiers de working via Accueil → Partitions → Bibliothèque locale → Ajouter des partitions… Les fichiers restent locaux ; la bibliothèque en garde des références. Ne pas déplacer le dossier après l’ajout, ni ajouter les originaux une deuxième fois.

L’application native fournit déjà cet ajout de fichiers. Le pack ne fabrique pas de local_library.json, ne modifie aucun profil et n’installe aucune banque sonore. Une collection nommée OpenScore — Dix chants et mélodies peut être créée manuellement. Les favoris et notes privées de l’application ne sont pas contenus dans ces fichiers musicaux. Les champs langue/instrument du manifeste ne sont pas annoncés comme filtres intégrés à l’interface.

Le job Windows 43272134450 a réussi dix ouvertures/exports, dix sauvegardes/réouvertures et dix rendus WAV sur des copies avec le stage 2006. Il ne teste pas le parcours graphique de la bibliothèque, l’édition réelle, la qualité visuelle ou l’écoute. Les sources originales sont conservées ; ouvrir les anciennes éditions peut demander une conversion. Pour travailler, enregistrer sous un nouveau nom et garder l’original.

Cette révision 0.1.2 enrichit seulement les documents du pack 0.1.1 réellement testé. Elle est optionnelle et extérieure au MSI 2007 figé. Aucune copie automatique de contenu dans l’application n’est prétendue. La publication et la vérification d’un téléchargement anonyme restent à effectuer par le responsable de livraison.
