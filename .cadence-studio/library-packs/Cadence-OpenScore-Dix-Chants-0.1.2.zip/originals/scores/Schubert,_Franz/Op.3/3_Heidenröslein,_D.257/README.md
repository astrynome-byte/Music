# Heidenröslein, D.257

__No.3 from [Op.3](..) by [Franz Schubert](../..)__

Transcribed and maintained by contributors to [OpenScore Lieder].

Please visit the [official score page] for more information.

[official score page]: https://musescore.com/openscore-lieder-corpus/scores/30321236
[OpenScore Lieder]: https://musescore.com/openscore-lieder-corpus

## External links

- [MuseScore] - view and listen to [this score][MuseScore], or download in a variety of formats.
- [IMSLP] - view the [source PDF file(s)][IMSLP] that this score was transcribed from.

[MuseScore]: https://musescore.com/score/30321236
[IMSLP]: https://imslp.org/wiki/Special:ReverseLookup/09270